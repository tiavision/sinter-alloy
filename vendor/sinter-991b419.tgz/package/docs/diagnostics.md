# sinter diagnostics

Generated from `src/compiler/diagnostic-docs.ts` by `npm run docs`. Every diagnostic links to its section here. Codes from SN500 up are warnings; the rest are errors and fail the build. `sinter check --strict` fails on warnings too, except the ones that depend on the machine or the network (SN525, SN526, SN527, SN528, SN533) and the heuristic ones (SN507, SN536) ([docs/strict.md](strict.md)). A code reported by the build rather than by a page, without a file and line, says so.

## SN101 unknown-attribute

Error, for example:

> `data-sn-txt` is not a sinter attribute. Did you mean `data-sn-text`?

An attribute starts with `data-sn-` but is not one sinter knows, usually a typo.

**Fix:** Use the suggested name. The attributes are listed in `llms.txt` and, in VS Code, completed from `html-custom-data.json`.

## SN102 wrong-element

Error, for example:

> `data-sn-for` must be on a `<template>`

The attribute or element is valid, but not here: lists and conditionals render from a `<template>`, `data-sn-path` belongs on `<html>`, `<sn-event>` inside `<sn-sync>`, options such as `data-sn-debounce` need an action on the same element (a method attribute or `data-sn-call`), `data-sn-attr` cannot bind the `value` or `checked` that a `data-sn-model` on the same control writes, and `data-sn-href` is on a link (`<a>`, `<area>`) whose `href` nothing else binds. A `data-sn-else` goes directly after a `data-sn-if` template, or after a `data-sn-for` template, where it is the list's empty state: that one takes no `data-sn-if` (choose inside it), and the list's own `data-sn-let` is not its.

**Fix:** Move it to where the message says, wrapping the content in a `<template>` if needed.

## SN104 unsupported-model

Error, for example:

> `data-sn-model` does not support `type="file"`; submit the form instead

Two-way binding has no meaningful value for this input type.

**Fix:** Submit the form with a method attribute (`data-sn-post`, …) on it; a form with a file input is sent as `FormData`.

## SN105 reserved-comment

Error, for example:

> this comment is one of the forms sinter marks lists and branches with (`<!--sn-->`, `<!--sn 4-->`, `<!--/sn-->`, `<!---->`): the page would take it for one

Every `data-sn-if`, `data-sn-for` and component chosen by data is marked in the page by a pair of comments, `<!--sn 4-->` (`<!--sn-->` in a row) and `<!--/sn-->`, and an empty comment separates text; the runtime and the early script find them by their exact text. An author's comment with exactly one of those texts would be taken for one. Any other comment, `<!--snippet-->` or `<!-- sn notes -->` included, is the author's.

**Fix:** Add a word to the comment, or remove it.

## SN106 anchor-in-raw-text

Error, for example:

> a `<template data-sn-for>` inside `<textarea>` is text to the HTML parser: it renders nothing

The content of `<textarea>` and `<title>` is raw text: the browser's parser reads no elements or comments there, so a list or branch inside one cannot be marked or rendered.

**Fix:** Bind the whole text instead: `data-sn-model` (or `data-sn-attr="{ value: … }"`) on the `<textarea>`, `data-sn-text` on the `<title>`.

## SN201 unknown-identifier

Error, for example:

> `contcts` is not defined here. Did you mean `contacts`?

An expression uses a name that is not a loop variable, state field, resource, magic name, helper or JavaScript global in this scope.

**Fix:** Fix the typo, declare the name in `data-sn-state`, or export it from the helpers module. Loop variables are only visible inside their `<template>`.

## SN202 forbidden-global

Error, for example:

> `window` is a browser API; expressions may use JavaScript, not the browser. Use a component's script

Expressions may use JavaScript built-ins but not browser APIs such as `window`, `document`, `fetch` or timers, so pages stay safe under a strict CSP and testable.

**Fix:** Move the browser code into a helper (for a pure function) or a component's script (`src/components/<name>.ts`, which owns imperative work).

## SN203 side-effect

Error, for example:

> value expressions cannot assign; move this to `data-sn-on-*`

A binding that produces a value (`text`, `attr`, `show`, `for`, …) tried to change state, which would run on every render. Path parameters of `$url` are read-only everywhere. Also: an expression called a function of the actions module. Actions run on elements (`data-sn-call`) or feed resources (`<sn-resource call>`), because their busy state, concurrency, optimistic layer and `then`/`catch` belong to an element.

**Fix:** Do the assignment in an event handler (`data-sn-on-click`) or in an action's `then`. To start an action from a handler (a key filter, `data-sn-then`, `<sn-resource then>`), put it on an element with an `id` and call `run('id')`: `<span hidden id="mark-read" data-sn-call="mail.markRead(open)"></span>` and `then="$result && run('mark-read')"`.

## SN204 optimistic-scope

Error, for example:

> `data-sn-optimistic` may only call `merge`, `upsert`, `remove`

An optimistic change is undone when the request fails, so it may only use the store functions that sinter can roll back.

**Fix:** Express the change with `merge`, `upsert` or `remove`; set other state in `then`.

## SN205 resource-mutation

Error, for example:

> `m.is_read = true` mutates a resource. Use `merge(m, {is_read: true})`

Resource data is read-only in expressions: it mirrors the server, and a direct write (an assignment, a mutating method such as `push()`, or `Object.assign()` on an item) would be lost on the next refresh or event.

**Fix:** Use the `merge()` call from the message, or copy the item with `structuredClone(c)` to edit it in state.

## SN206 unknown-namespace-member

Error, for example:

> `m.inbox_titel` is not exported by namespace `m`. Did you mean `inbox_title`?

A helper namespace (for example paraglide messages) has no export of that name.

**Fix:** Use the suggested name, or add the export to the namespace module.

## SN207 unsafe-sink

Error, for example:

> `onclick` cannot be bound with `data-sn-attr`; use `data-sn-on-click`

The binding could run script or inject markup from data: event-handler attributes, `style`, `srcdoc`, `innerHTML`, bindings on `<script>`, `<link>`, `<base>` and similar elements, any binding on a `<meta>` but `data-sn-attr="{ content: … }"` on one with a literal `name`, `property` or `itemprop` (never `http-equiv` or `charset`), URL templates that do not start with a literal path (or with a literal origin that lacks its `/` before a value; a link's, `data-sn-href`, may also start with `?` or `#`), persisted password fields, or `constructor`, `__proto__` and `prototype` named in an expression.

**Fix:** Use the safe equivalent the message names: `data-sn-on-*` for events, `data-sn-style` for styles, a literal `/path` (or `https://host/`) at the start of a URL template.

## SN208 type-error

Error, for example:

> Property 'nmae' does not exist on type 'Contact'. (TS2339)

TypeScript found a type error in an expression. Reported by `sinter check`, `vite build` (when the project has TypeScript) and the editor integration.

**Fix:** Fix the expression, or the type: `type` on `<sn-resource>`, the OpenAPI spec, or a JSDoc cast in `data-sn-state`.

## SN209 name-conflict

Error, for example:

> `s` is already defined here by `data-sn-let`; use another name

A name is declared twice where one is read: a `data-sn-let` name is inlined wherever it is read, so it cannot share a name with a state variable or loop variable in its scope, or be redeclared inside it; two `<sn-resource>` elements on one page cannot share a name. A resource cannot take the name of a store function (`refresh`, `upsert`, `merge`, `remove`, `page`, `showModal`, `close`, `emit`, `run`, `navigate`).

**Fix:** Rename the let, the state or loop variable, or one of the resources (or remove the duplicate).

## SN210 url-list-mismatch

Error, for example:

> `$url.tag` is a list elsewhere on the page (a `<select multiple>` or a checkbox with a `value`), and one value here; bind it as a list everywhere

A `$url` parameter is a list (an array parameter, written as repeated keys: `?tag=a&tag=b`) when a `<select multiple>` or a checkbox with a `value` attribute binds it; the build decides this, so every place must agree. A parameter no such control binds is one value, and a list written to it would be lost on reload.

**Fix:** Bind the parameter the same way everywhere (two parameters if you need both), or write one value to it; a single value written to an array parameter is wrapped in a list for you.

## SN211 url-list-condition

Error, for example:

> `$url.tag` is a list and always truthy; use `$url.tag.length`

An array parameter always reads as a list, `[]` when the URL has none, and an empty list is truthy in JavaScript: a condition on the bare parameter always holds.

**Fix:** Test its length: `data-sn-if="$url.tag.length"`, or `$url.tag.includes('go')` for one value.

## SN212 url-object-value

Error, for example:

> `$url.filter` holds a string (or a list of strings); an object cannot be written to it. Write the field you mean, such as `$url.filter = x.id`

The URL holds strings: an object, a function or an instance (`{…}`, `() => …`, `new Date()`) written to a `$url` parameter has no form a reload could read back. At run time such a value removes the parameter, with a dev warning.

**Fix:** Write the string or number you mean (`$url.from = d.toISOString().slice(0, 10)`), or keep the object in state.

## SN213 element-of-anchor

Error, for example:

> `$el` in a `data-sn-if`: the condition is marked by comments in the page, so there is no element to read

A `data-sn-if`, a `data-sn-for` and the `use` of `<sn-component>` render a variable number of nodes between two comments; they have no element of their own for `$el` to name.

**Fix:** Read the element in a binding inside the template (each rendered element has its own `$el`), or decide with state instead of the element.

## SN301 unknown-resource

Error, for example:

> resource `mesages` is not declared on this page

A store call, `$meta` or embedded data (`data-sn-resource`) names a resource that no `<sn-resource>` on the page or its partials declares. Store functions and `$meta[…]` take the resource itself, not its name. A resource chosen by an expression (`page(searching ? results : messages, 'next')`, `||` or `??` between resources, or a `data-sn-let` name that is one) is checked for each resource it can take. Also reported: a name as a string (`refresh('people')`, `$meta[s ? 'a' : 'b']`), and a store call whose resource argument cannot be listed from the source (a state variable, a helper's result, `$event.detail`, `a && b`).

**Fix:** Fix the name or add the `<sn-resource>` element. Write the resource, not a string: `refresh(people)`. For a choice that cannot be listed, write it between resources: `?:`, `||` or `??`, or a `data-sn-let` name whose value is one (`data-sn-let="{ shown: searching ? results : messages }"`, then `page(shown, 'next')`); a choice kept in state becomes `tab === 'inbox' ? inbox : sent`.

## SN303 unknown-meta-field

Error, for example:

> `$meta.contacts.loadng` is not a status field. Did you mean `loading`?

`$meta.<resource>` has a fixed set of fields: `loading`, `error`, `loadedAt`, `total`, `live`, and with `paginate` also `pages`, `from`, `to`, `hasPrev`, `hasNext`; `page` on a numbered list (`numbered: true`), or a keyset list with `jump: true`. There is no `pending`: an element shows its own request with `aria-busy`.

**Fix:** Use the suggested field. A pagination field needs `paginate` on the resource.

## SN304 keyset-jump

Error, for example:

> keyset pagination cannot jump to a page number. Add `jump: true` to `paginate` if the server also accepts an offset, or use `numbered: true`

Keyset (cursor) pagination only knows the next and previous page, so `page(messages, 7)` has nothing to jump to, unless the server can also skip items by offset. A computed target (`page(messages, dir)`) is not this error: `sinter check` types it as a direction, and at run time a page number is refused without a request. `append` pagination takes only the literal `'next'`.

**Fix:** If the API accepts an offset next to its cursor, add `jump: true` to `paginate` (and `params: { offset: 'skip' }` where the server names it otherwise): the jump is sent as an offset and `prev`/`next` continue by cursor. Otherwise use `numbered: true` in `paginate`, or only step with `first`, `prev`, `next` and `last`.

## SN306 component-cycle

Error, for example:

> `<comment-card>` → `<reply-list>` → `<comment-card>` uses itself with no `data-sn-for` or `data-sn-if` template between, so it would never end

A component uses itself, directly or through other components, and nothing in between depends on data: expanding it would never end.

**Fix:** Put the inner use in a `<template data-sn-for>` over the children (or a `<template data-sn-if>`), so data ends the recursion.

## SN307 openapi-invalid

Error, for example:

> OpenAPI spec `api.yml` is not an OpenAPI 3 document (needs `openapi: 3.x` and `paths`)

The spec of an API (`sinter({ apis: { main: { openapi } } })`) is missing, unreadable, or not OpenAPI 3.

**Fix:** Fix the path in the Vite config, or convert a Swagger 2 spec to OpenAPI 3.

## SN308 unknown-schema-field

Error, for example:

> the response of `GET /articles` has no `articls`. Did you mean `articles`?

The resource matched an operation in the OpenAPI spec, but its `select` or `total` path, or `more` in `paginate`, is not in the response schema.

**Fix:** Fix the path in `select`, `total` or `more`, or the spec if the API changed.

## SN309 unknown-element-id

Error, for example:

> no `<dialog id="compose-dialg">` on this page. Did you mean `compose-dialog`?

`openDialog(id)` and `closeDialog(id)` name a `<dialog>` by its literal `id`, which must be on the page or one of its partials; `closePopover(id)` names an element with `popover` the same way. `run(id)` starts the action of the element with that literal `id`: an element on the page or one of its partials with `data-sn-post`, `-put`, `-patch`, `-delete` or `data-sn-call`. Also reported: an id that is not a string literal, an element without an action, an element inside a `data-sn-for` row (every row would have the id), and an id that more than one element has.

**Fix:** Fix the id, or add `id` to the `<dialog>` (or the `popover` element). `closeDialog()` without an argument closes the dialog around the element, `closePopover()` the popover. Fix the id, or give the action element an `id`. For a row's action, put one action element outside the list and pass the row through state: `open = m; run('mark-read')`.

## SN310 unknown-action

Error, for example:

> `pgp.decrpyt` is not exported by the actions module. Did you mean `pgp.decrypt`?

`data-sn-call` and `<sn-resource call>` name a function the actions module (`src/sinter.actions.js` or `.ts`) exports, directly or through `export * as ns`.

**Fix:** Use the suggested name, or export the function from the actions module.

## SN312 invalid-component

Error, for example:

> a component's root renders at most one element; `<article-preview>` has 2 elements at the top of its template

A file in `src/components/` is not a valid component: it needs one `<template data-sn-props="{ …props }">` (a plain `<template>` for a component without props; and optionally a `<style>` and a top-level `<script>`, its script) whose root renders at most one element: one element, a `data-sn-if`/`data-sn-else` chain of them, a component, `<sn-component use>`, or a `<slot>` whose default and fills are roots. A component whose template holds head elements only is a head component, which holds any number of them. Also reported: two top-level templates where none has `data-sn-props`, `data-sn-if`, `data-sn-else`, `data-sn-for` or `data-sn-text` on the file's template without `data-sn-props` (that template is the declaration, not a branch, list or text), two slots with the same name, a head component with a script, a `<style>` together with a `<name>.css` file beside the component (its styles are in one place), two top-level `<script>` elements, a `<script>` together with a script file beside the component (its script is in one place), a `<script lang>` other than `ts`, a top-level `<script>` of another `type` (JSON-LD goes inside the template), and `<sn-component use>` naming a head component.

**Fix:** Wrap the markup in one element inside `<template data-sn-props>`: the caller's classes, attributes and handlers land on it.

## SN313 unknown-prop

Error, for example:

> `artcle` is not a prop of `<article-preview>`; its props are `article`, `compact`. Did you mean `article`?

`data-sn-with` on a component passes a name its `data-sn-props` does not declare, or leaves out a prop that is not optional. Also reported: `data-sn-model` on a component without a `value` prop and a `change` event.

**Fix:** Fix the name, pass the missing prop, or declare it in the component (`{ article: Article; compact?: boolean }`).

## SN314 unknown-slot

Error, for example:

> `<article-preview>` has no slot `meta`. Its slots are `footer`.

Content on a component's tag goes into its `<slot>` elements: a `slot="name"` names a `<slot name>`, the rest goes into the default `<slot>`. Content no slot takes would be dropped.

**Fix:** Fix the slot name, or add the `<slot>` to the component.

## SN315 unknown-component-event

Error, for example:

> `<task-ring>` does not declare the event `pik`; `data-sn-emits` declares `pick`. Did you mean `pick`?

A component's events are the ones its `data-sn-emits` declares: `emit()` inside it, and `data-sn-on-<event>` on its tag, must name one of them (or, on the tag, a DOM event such as `click`).

**Fix:** Fix the name, or declare the event with its detail type: `data-sn-emits="{ pick: 'done' | 'open' }"`.

## SN317 no-item-source

Error, for example:

> `selected` has no source: `merge()` acts on an item where it came from, and nothing says which resource `selected` is an item of

`merge(item, …)` and `remove(item)` change the item in the resource it came from, found by its key: a row of a `data-sn-for` over a resource (also a filtered one, or one a helper returns), an element of one (`contacts[0]`, `.find(…)`), a single resource, a component prop that is one of those, or state a handler assigned from one (`sel = m`). The item here is none of these. Also reported: the removed forms with a resource name, `merge('name', item, …)` and `remove('name', item)`, and a row of a helper that takes more than one resource.

**Fix:** Drop the resource name from the old forms. Otherwise pass the row itself; for `$result`, rely on write-through (with a spec) or `merge()` its fields into the row; a server event's payload goes through `<sn-event resource op>`; a custom element changes the resource through the instance API.

## SN318 invalid-layout

Error, for example:

> `src/layouts/site-layout.html` is not a layout: a layout is a whole document whose `<html>` declares its props, `<html data-sn-props="{ …props }">`

A file in `src/layouts/` is a layout: a whole document (`<html>`, `<head>`, `<body>`) whose `<html>` carries `data-sn-props` with its props type (left out, it takes none). Also reported: a page that passes `data-sn-with` to a layout that declares no props, `data-sn-props` anywhere else, a default slot in the layout's head (the default slot is the page's body), `data-sn-emits` on a layout, a layout with a script beside it, a layout and a component with the same name, and a layout built as a page. A page that uses a layout is the layout's tag at its top level and nothing else (a doctype and comments are allowed): its content goes into the layout's slots, the attributes of `<html>` on the tag. A layout's tag anywhere else (inside a component, another layout, or other markup) is reported too, and so is `data-sn-early` on it.

**Fix:** Write the layout as a document: `<!doctype html><html lang="en" data-sn-props="{ title?: string }"><head>…<slot name="head"></slot></head><body>…<slot></slot></body></html>`; a layout without props needs no `data-sn-props` (`<html lang="en">`), but one whose pages pass `data-sn-with` must declare those props. Name head slots; leave `src/layouts/` out of the build's inputs (a glob over every `.html` picks it up). Move the content inside the tag, with `slot="…"` for a named slot; write `lang`, `data-sn-path` and the like on the tag.

## SN320 head-content

Error, for example:

> `<div>` cannot be in the `<head>`: the browser would move it, and everything after it, into the body

After components are expanded, a head holds only head elements: `<title>`, `<meta>`, `<link>`, `<script>`, `<style>`, `<noscript>`, `<base>` and `<template>`. `<sn-resource>` and `<sn-sync>` go in the body: they are page-wide wherever they are written, and their requests start in the head anyway. The browser ends the head at anything else and moves it, with every element after it, into the body. sinter parses heads so that a component's tag stays where it is written: the element it expands to must be head content.

**Fix:** Move the element into the body. In a head, use head components (`<template data-sn-props>`).

## SN321 duplicate-head

Error, for example:

> a second `<title>` in the head: the page would have two

After a layout, its slots and its head components are merged, the head has two of an element a page has once: `<title>`, `<base>`, `<meta charset>`, `<link rel="canonical">`, and the `<meta>` with `name` `viewport`, `description` or `robots`, or `property` `og:title`, `og:description`, `og:url`, `og:type`, `twitter:card`, `twitter:title` or `twitter:description`. Elements inside `data-sn-if`, `data-sn-else` and `data-sn-for` templates count: two in the branches of one `data-sn-if` / `data-sn-else` are one, one at the top level and one in a branch are two, and one in a `data-sn-for` template is one per row.

**Fix:** Keep one: pass the value to the one that is there (a prop of the layout or head component), or replace a slot's fallback with the page's own element.

## SN322 ships-javascript

Error, for example:

> about.html must ship no JavaScript (`sinter({ static })`), but `data-sn-on-click` runs in the browser

The page is in `sinter({ static })`, the pages that must ship no JavaScript, but something on it runs in the browser: a binding over state a handler writes, data, `$url`, `$now` or a helper that cannot run at build time, a handler, an action, a resource or stream, a model, or a component with a script. The error is where that was written, in the page, a component or the layout, once for each. A binding kept in the browser by a helper call says which call and why the helper cannot run at build time: the name outside JavaScript's own deterministic globals it reaches (`Date`, `window`, `fetch`, …), where, and through which functions.

**Fix:** Remove what runs in the browser, or make it a constant (a literal, a prop given as one, state nothing writes, a `file:` resource, a helper call over those). For a helper, keep what reads the clock, the locale or the browser out of the functions the page calls at build time (each exported function counts on its own). If the page is meant to run it, take the page out of `static` in vite.config.

## SN323 needs-site

Error, for example:

> `$canonical` is the page's absolute URL, and the build does not know the site's origin: set `sinter({ site: 'https://…' })` in vite.config

`$site` (the site's root URL) and `$canonical` (the page's URL) are absolute: they need the origin the site is served at, which only the configuration knows. Also: a `<link rel="canonical">` the page writes itself must name an absolute URL, since `$canonical` is that URL.

**Fix:** Set `sinter({ site: 'https://example.com' })` in vite.config (an origin, no path: a site under a path sets Vite's `base`). For a canonical link of your own, write it absolute, e.g. `$site + '/en/about/'` is what the build would write.

## SN324 lazy-package-use

Error, for example:

> `openpgp.encrypt(…)` is not awaited: `sinter({ lazy })` loads openpgp on first call, so every call returns a Promise

The package is in `sinter({ lazy })`, so the app's imports of it are stubs that load it on first call: each call returns a Promise, and nothing else of the package is there before it has loaded. So a value imported from it may only be called, and each call must be waited for (`await`, `return`, `.then`, `void`, or `Promise.all`). Refused: a call nothing waits for, `new`, `instanceof`, reading a constant or setting (`openpgp.enums`, `openpgp.config`), passing a function or the namespace as a value, `import 'pkg'` for its side effects (not a stylesheet or asset of it, `import 'pkg/style.css'`, which loads none of its code), and re-exporting it. Also, in markup: a helper declared in a module that reaches a lazy package is called outside a `data-sn-let` or a prop (only a let can wait for the module; helpers of other modules stay ordinary helpers); and `data-sn-import` or `data-sn-preload` names a package that is not in `lazy`.

**Fix:** Await the call. For classes and constants, load the package where they are needed with `await import('pkg')`, or move that code into a component script, which loads with the package. For a helper of a module that reaches a lazy package, name its value in a `data-sn-let` (`data-sn-let="{ tree: doc.parse(body) }"`) and read the name, which is `undefined` until the module has loaded; keep the helpers that do not need the package in a module that does not import it. In markup, name a package of `lazy`, or add it there.

## SN325 lazy-package-bundled

Error, for example:

> the page bundle of mail.html contains openpgp, which `sinter({ lazy })` loads lazily: mail.html → src/lib/autocrypt.ts → some-lib → openpgp

A page's bundle (its own chunk and the chunks it imports, or its early file) contains a lazy package after all, so the page downloads it with itself: another package imports it (the app's imports of it are stubs, a package's are not), or the early module reaches it. Also: an app module that some module of the page loads with `import()` is imported statically by the page too, so the split does nothing for that page.

**Fix:** Add the other package to `lazy` as well, or load it with `import()`. For the app's own split, import the module only with `import()` where the page reaches it, or not lazily at all.

## SN326 unknown-operation

Error, for example:

> `GET /contacs` is no operation of the API `main`. Did you mean `/contacts`?

With `sinter({ apis })`, a path in `src`, an action or `<sn-sync src>` is relative to an API, and the API accepts only the operations its spec or its `operations` declare, with the method the place implies (`GET` for a resource unless it has `method`, the attribute's for an action). Also reported: `api:` naming no API, and a path without `api:` when several APIs are configured and none is the default (`default: true`).

**Fix:** Use the suggested path (the editor completes them), add the endpoint to the spec, or declare it in the API's `operations`. A path written with the base in it (`/api/contacts` with `base: '/api'`) drops the base.

## SN327 undeclared-query

Error, for example:

> `GET /articles` of the API `main` declares no query parameter `tagg`. Did you mean `tag`?

A query parameter in a path to a configured API must be one its operation declares (in the spec, or in `query` of the API's `defaults` or `operations`), and every required one must be given. The parameters `paginate` adds count as given, and are checked too. The same rule without `sinter({ apis })`, with a bare `openapi` spec, is the warning `SN505`: there the parameter has nowhere to be declared.

**Fix:** Use the suggested name, give the required parameter, or declare it: in the spec, or with `query: ['name']` in the API's `defaults` for the operation.

## SN328 absolute-url

Error, for example:

> `https://api.example.com/v1/contacts` names its API's origin: write `/contacts`

With `sinter({ apis })`, a page writes paths relative to an API, and the origin is the API's `base`. An absolute URL would bypass the API's checks and settings.

**Fix:** Write the path relative to the API that has this base (the quick fix does), with `api:` when it is not the default API; for an origin that is no API, add one to `apis`.

## SN329 api-config

Error, for example:

> sinter({ apis }): `main.base` is `undefined` (an environment variable that is not set?); it does not fall back to the spec's server

The `apis` option is invalid: an API setting that does not exist, a `base` that is not `''`, a same-origin path or an `https://` URL (or is `undefined`), `defaults` naming an operation the spec does not have, `operations` naming one it has, two APIs with `default: true`, a shape setting renamed (`items` is `select`), or a top-level `openapi` next to `apis`.

**Fix:** Follow the message: set the environment variable, move the endpoint between `defaults` and `operations`, write the new name, or move `openapi` into an API.

## SN330 configured-shape

Error, for example:

> `select` of `GET /articles` is `articles` (`main.defaults`), not `posts`: every page reads one shape from an endpoint

What an endpoint returns (`select`, `total`, `key`, `type`) is said once: when the API's `defaults` or `operations` give a value, a resource of that operation does not write a different one, because two pages would read different shapes from one endpoint. The same value is the warning `SN518`.

**Fix:** Remove the attribute, or change the configured value if the page is right.

## SN331 invalid-slot

Error, for example:

> the slot `cell` is written with `?`; every slot may be left unfilled, and its placement shows its default

A slot that passes data is declared, placed or filled wrongly. It is a `Slot<T>` member of the props type literal in `data-sn-props` (not in a type alias, not with `?`, not in a head component's or a layout's props; the app's types module may not export a type named `Slot`), placed with `<slot name="…" data-sn-with="{ … }">`, whose default is one plain element or a `data-sn-if`/`data-sn-else` chain of them (anything broader comes with the component root, step 4 of the component-libraries proposal). A fill is elements with `slot="…"`; a `<template slot>` only starts an if/else chain. An unnamed `<slot>` in a fill places the children of the element the default renders: an error when it renders none, and the default's element may not declare names (`data-sn-let`, `data-sn-state`) its children read, since they move into the fill without it. Also reported: a `<slot>` that no component or fill encloses (on a page, or in a page's slot content).

**Fix:** Write the slot as `cell: Slot<{ row: Row }>` in the props type literal, place it with `data-sn-with`, give the placement one element as default, and move names the children read onto the `<slot>`'s `data-sn-with` or inside the element. Remove a `<slot>` from a page.

## SN332 build-time-source

Error, for example:

> `refresh` reloads, and a `file:` resource is a constant: it is read at build time and never loads or changes; it takes only `name`, `src`, `type`, `select`, `key`, `order`, `drafts` and `fields`

A `file:` source (`<sn-resource src="file:./post.md">`) reads the project at build time: one file (its text, a `.json` file's parsed value, a markdown file's frontmatter and `body`), or with a glob (`file:/content/posts/*.md`) a list with one entry per file, each with its `slug`, `dir` and `path`. The path is a literal, relative to the file that writes it (a page, a layout, a component) or `/…` from the project root, and inside the root; the file must exist, a `.json` file must parse, frontmatter must be YAML fields without anchors, aliases or tags, and must not name `body`, `dir` or `path`, which sinter writes. In a glob each `.json` file is one object, and two entries may not share a key (`slug` by default). `order` sorts a list and `drafts` names a field that leaves an entry out of a build; `items` picks a list out of one JSON file. The resource is a constant: what would load, page, refresh, cache or change it is refused (`refresh`, `cache`, `paginate`, `for`, `call`, `when`, `then`, `early`, `method`, store functions that name it or change one of its items, write-through, `<sn-event>`s). `file:` is a source of `<sn-resource src>` only, not of an action or `<sn-sync>`. `fields` and `drafts` are a build-time source's only (`file:`, `content:`): on a fetched resource they would do nothing.

**Fix:** Write a literal path or glob in the project, or fix the file it names. Give two files with one name a `slug` of their own in their frontmatter (or a `key` that tells them apart). Leave out the attribute that would load or change it, and a build-time source's attribute on a fetched resource; for data that changes, serve it from an API and use a URL. To change the values a page shows, keep them in `data-sn-state`, initialized from the resource.

## SN333 invalid-text

Error, for example:

> `data-sn-text` and `data-sn-if` on one `<template>`: a text node is one binding; the condition or the loop goes on a template around it

A `<template data-sn-text>` renders a text node and nothing else: it takes no other attribute (`data-sn-if` and `data-sn-for` go on a template around it, anything else on an element around the text), and content inside it is dropped.

**Fix:** Wrap it: `<template data-sn-if="…"><template data-sn-text="…"></template></template>`, or put the text in an element.

## SN334 empty-root

Error, for example:

> `<ui-panel>`'s root may render nothing, so `id` on its tag would point at an element that may not exist

A component whose root may render nothing (an if chain without a `data-sn-else`, `<sn-component use>`, or a component tag whose own root may) takes no `id`, `data-sn-model`, action (`data-sn-post`, `-put`, `-patch`, `-delete`, `data-sn-call`) or `data-sn-transition` on its tag: each points at, or depends on, the element the tag becomes. A root with no element at all is the same case: a `<slot>` at the root given a text fill (`<template slot data-sn-text>`) renders one text node, so every attribute on the tag but `data-sn-with` and `data-sn-early` is SN334 there, the plain ones (`class`) too, since none has an element to land on.

**Fix:** Put the attribute on an element inside the component that is always there, give the chain a `data-sn-else`, or wrap the tag in an element that carries it. For a text root, give an element as the fill, or wrap the tag.

## SN337 invalid-library

Error, for example:

> `@acme/ui` is in `sinter({ libraries })` and its package.json has no `"sinter"` field: a component library names the folder of its components

A package in `sinter({ libraries })` is a component library (docs/libraries.md): installed, with `"sinter": "./sinter"` in its package.json naming a folder inside the package that has a `components/` folder. Its components share their first segment (`ui-card`, `ui-tree`: `ui`), the prefix it owns, and a name is in `components/` (public) or `components/internal/`, not both. Each component library owns the first segment of its components' names. Two configured libraries with one prefix, or an app component (`src/components/`) whose name starts with a library's prefix, fail the build: a tag names exactly one component, and there is no shadowing.

**Fix:** Install the package, or take it out of `components` if it is not a component library. A library's author adds the `"sinter"` field and folder, and renames components to share one prefix. Rename the app component (`app-button`). To change how a library component looks or behaves everywhere, write a wrapper component of your own that uses it, with fills for its slots. Two libraries with one prefix cannot be used together.

## SN339 library-component

Error, for example:

> `<ui-node>` is internal to `@acme/ui` (`components/internal/`): only its own components use it

A tag with a library's prefix names one of its components. Those in its `components/internal/` folder are its own: the app's markup (pages, layouts, components, fills and slot content) uses the public ones, in `components/`. A tag with the prefix that names no component of the library is an error too, and so is a `<sn-component use>` map in a library's markup that names a component outside it: a library chooses among its own components.

**Fix:** Use one of the public components the message lists, or fix the name. A library's author moves a component the app needs out of `components/internal/`.

## SN340 invalid-entry-page

Error, for example:

> `data-sn-for` on `<html>` needs `data-sn-path` with exactly one pattern to fill from each entry, e.g. `data-sn-path="/blog/:slug"`

`<html data-sn-for="post in posts">` (or on a layout's tag) builds the page once per entry of `posts`, a `file:` glob the page declares outside any template, and writes each at its `data-sn-path` pattern filled from the entry. The value is `<name> in <list>`; the name is the entry, readable in the whole page as a resource is (not a store function's or a magic name). The page has exactly one pattern, with parameters, and no other path: a fixed path would be written once per entry. Each entry of an `<html data-sn-for>` list fills the page's pattern: every `:param` takes the entry's field of that name, which must be a string or a number, one path segment (not empty, not `.` or `..`, no `/`). Two entries that fill the same path would be one page.

**Fix:** Write `data-sn-path="/blog/:slug"` beside it, declare the list on the page (`<sn-resource name="posts" src="file:/content/posts/*.md">`), and name the entry `post in posts`. Give the entry the field (in its frontmatter, or a file name that makes its `slug`), make it one segment, or give two entries different values.

## SN342 unknown-collection

Error, for example:

> `post` is not a collection of the content module (it has `posts`, `tags`)

`<sn-resource src="content:posts">` reads a collection of the content module (`src/sinter.content.ts`): an export made with `collection({ key, load })`, loaded before any page compiles. The name must be one of its exports. In the dev server, a content module that failed to load reports its error here, on each page that reads a collection.

**Fix:** Name an exported collection, or export one: `export const posts = collection({ key: 'slug', load: async () => … })`. If the module failed to load, fix the error it names.

## SN343 broken-entry-link

Error, for example:

> `index.html` links to `/blog/helo`, which `/blog/:slug` (blog/post.html) matches, but no entry is there. Did you mean `/blog/hello`?

A build knows every page an `<html data-sn-for>` template was written at, so a link in a built page to a path its pattern matches but no entry has would be a 404. The links checked are the built HTML's root-relative `href`s: from the markup, constants, folded expressions and markdown. A link built in the browser at run time is not checked. Reported by the build, without a file and line.

**Fix:** Link to an entry that exists (the build suggests the nearest), give the entry that slug, or drop the link.

## SN344 content-fields

Error, for example:

> browser code reads `products`, a collection, so it would ship to the page: name the fields it gets with `fields="…"`

A collection (`content:`) holds what a loader returned, which can be more than a page shows: a CMS's internal fields, drafts' notes, prices for another market. What bindings read is written into the HTML at build time and ships nothing; but when code in the browser reads the collection (a filter as you type, a handler), the list is embedded in the page, and a collection is embedded only with `fields`: the fields of each entry it ships. A page per entry (`<html data-sn-for>`) built from a collection follows its list's `fields`.

**Fix:** Add `fields="sku,name,price"` with what the browser code reads, or keep the reads at build time (bindings over constants fold). Fields left out are `undefined` in the browser.

## SN345 url-param-entry

Error, for example:

> `$url.slug` on a page per entry (`<html data-sn-for>`): each entry's page is written at its own path, so `:slug` is the entry's field, `post.slug`

A page with `data-sn-for` on `<html>` is written once per entry, each at its pattern filled from the entry, as a page with a fixed path. Its pattern's parameters are the entry's fields, known at build time; read through `$url` they would be read in the browser, and keep the page from being written at build time.

**Fix:** Read the entry's field: `post.slug` for `:slug`, where `post` is the name in `data-sn-for="post in posts"`. A query parameter (`$url.tab`) is fine.

## SN346 kept-element

Error, for example:

> `data-sn-permanent="player"` binds, and about.html has another element of that name: a kept element that binds is one markup, from one place (a layout or a component), on every page that keeps it

An element with `data-sn-permanent` is kept as it is when a link swaps the next page in (`sinter({ swap: true })`): the same element, playing or scrolled, moves into the next page where it has an element of the same name, and the next page's code takes over its bindings. So it is one element of the page, named with letters, digits, `-` and `_`, outside any `<template>`, once per page; its nodes are numbered in a range of their own, from its name (two names that get the same range, or more than 1000 bound nodes, are reported); and when it binds, every page that keeps it has the same markup, written in one place.

**Fix:** Give the element a plain name; write a kept element that binds once, in the layout or a component every page uses; rename one of two names that clash.

## SN347 session

Error, for example:

> `data-sn-signed-in` needs an API with a `token` (`sinter({ apis: { main: { token } } })`)

`data-sn-signed-in` on a page's `<html>` (or its layout's tag) sends a visitor with no token stored to the API's `token.signIn` page, with the return URL, before anything paints. It needs one API with a `token` and a `signIn` (with several, the one the page's resources use, and only one), its value reads only `$url` (the early script decides it before the page module runs), and it cannot be on the sign-in page itself (a loop). It is a convenience, not security: the server still refuses the requests. `signOut()` removes the tokens of the APIs that have one: in an app without one it would do nothing, so it is refused too.

**Fix:** Give the API a `token` with `signIn`; keep the condition to `$url` (`$url.feed == 'following'`); remove the attribute from the sign-in page. Without a token, sign out as the session works: a request to the server that ends it, then `clearStored()` in app code.

## SN348 removed-option

Error, for example:

> sinter({ messages }) is removed: the messages are a content namespace. Export `inlang()` from the content module, …

The Vite config gives the plugin an option that sinter no longer has. Before 1.0, an option can be removed; the message names what replaces it.

**Fix:** Follow the message, then remove the option. `npx sinter migrate --write` writes the replacement where it can (for `messages`, `inlang()` and `languages()` in the content module).

## SN349 component-location

Error, for example:

> `<task-ring>` is both `task-ring.html` and `task-ring/task-ring.html`: a component's HTML is in one place

A component's HTML is `<name>.html` in the components folder (`src/components/`, a library's `components/` or `components/internal/`), or `<name>/<name>.html` in a folder of its own, beside the files that go with it: its script, its early renderer, and modules and tests of its own. Only those two places name a component, so an HTML file anywhere else in the folder would silently not be one: a component in both places, another HTML file in a component's folder, HTML in a folder that is not named after a component inside it (folders do not group components: the tag is the file's name), and HTML at any depth below that (`forms/text-input/text-input.html` and `task-ring/parts/ring-label.html` are no components, as component tags are one namespace). A folder with no HTML, of modules only, is fine; `node_modules` and dot-folders are not looked in.

**Fix:** Keep one of the two places for the component. Move another HTML file out of the component's folder: a component of its own goes to `<name>.html` or `<name>/<name>.html` directly in the components folder, so `forms/text-input/text-input.html` becomes `text-input/text-input.html`.

## SN401 parse-error

Error, for example:

> `data-sn-for` takes `item in list` or `(item, i) in list`

An attribute value has the wrong form: a JavaScript syntax error (the column points inside the attribute), or a value outside what the attribute accepts, such as `paginate` or `data-sn-concurrency`.

**Fix:** Fix the value as the message says. Handlers are statements separated by `;`; value bindings are a single expression.

## SN501 unused-resource

Warning, for example:

> resource `addressbooks` is declared but never read

The page fetches a resource that nothing on it uses, which costs a request on every load. A resource with a `then` handler counts as used.

**Fix:** Remove the `<sn-resource>`, or use it.

## SN502 non-reactive-value

Warning, for example:

> `Date.now()` in a binding never updates. Use `$now`

The binding reads the time or a random number once and is never re-rendered by it.

**Fix:** Use `$now`, which sinter updates, or compute the value in a handler.

## SN503 data-bound-id

Warning, for example:

> `id` bound from data can shadow globals other scripts read (DOM clobbering)

An `id` or `name` set from server data can create a global that overrides one another script relies on.

**Fix:** Start the value with a literal string (`'contact-' + c.id` or `` `contact-${c.id}` ``) or use a `data-*` attribute instead. A choice passes when each branch starts with one or sets no attribute: `c.id ? 'contact-' + c.id : null`.

## SN504 untyped-resource

Warning, for example:

> resource `contacts` has no type: expressions using it are not checked

The type checker has no type for the resource, so expressions that use it are not checked. Reported by `sinter check` only.

**Fix:** Add `type="Contact[]"` with a type from `src/sinter.types.ts`, configure an OpenAPI spec that matches `src`, load it with `call` (typed by what the action returns), or write `type="any"` to opt out.

## SN505 undeclared-query-in-spec

Warning, for example:

> `GET /articles` declares no query parameter `tagg`. Did you mean `tag`?

A literal query parameter in `src` is not declared by the matched OpenAPI operation, usually a typo the server would ignore. The same rule with `sinter({ apis })` is the error `SN327`, since the API's config can declare the parameter (`query` in its `defaults`).

**Fix:** Use the suggested name, or add the parameter to the spec.

## SN506 untyped-event

Warning, for example:

> event `contact_updated` has no type: expressions reading its payload are not checked

An `<sn-event>` reads its payload but has no `type`, so those expressions are not checked. Reported by `sinter check` only.

**Fix:** Add `type` with the payload's type: the object the server sends, so `value="contact"` on a resource of `Contact[]` is `type="{ contact: Contact }"` (the hint names it), or a type from `src/sinter.types.ts`. `type="any"` opts out.

## SN507 complex-expression

Warning, for example:

> `data-sn-on-click` is too complex for markup: 5 statements in one handler (limit `statements`: 4). Move the logic into a helper (pure, `x = fn(…)`) or an action

An expression has more structure than markup should hold. The measure is structure, not length: statements in a handler (`statements`, 4), comma sequences (`sequences`, 0), steps one `&&`/`||`/`?:` used as a statement runs (`guarded`, 1: `a && closeDialog()` is fine, `a && (b = 1, closeDialog())` is not), `?:` nesting (`ternaries`, 2), operations in an arrow function (`arrow`, 8; a block body `{ … }` always counts), and operations in one expression or statement (`operations`, 15) as a backstop. Operations are calls, operators, assignments and computed access; names, member paths (`a.b.c`) and literals are free. Object attributes (`data-sn-state`, `-let`, `-attr`, `-class`, `-style`, `-prop`) are measured per property value. A warning by default.

**Fix:** Move the logic into a helper (pure) and apply its result in the handler, `sel = rowClick($event, sel, key)`, or into an action for side effects (`data-sn-call`). Split independent steps into separate `;` statements. Limits and the level are options of the Vite plugin: `sinter({ complexity: { statements: 4, level: 'error' } })`; `level: 'off'` turns the check off.

## SN509 run-cycle

Warning, for example:

> `run()` cycle: `#save` `data-sn-catch` (index.html:12) runs `#save`, which starts the first step again

`then`/`catch` handlers start each other again through `run()` (and `refresh()`, whose load runs the resource's `then`), so the requests may never stop. The message lists every step with its handler and line. A guarded retry is a deliberate cycle: `strict: { allow: { SN509: 'a retry, at most 3 times' } }` keeps it a warning.

**Fix:** Make sure a step stops: a condition that becomes false (`$error.status === 503 && tries < 3 && run('save')`), or drop one step.

## SN510 redundant-write

Warning, for example:

> `merge(article, $result.article)` is what write-through does: the response of `POST /articles/{slug}/favorite` is `Article`, which `articles` holds; remove this write, or add `data-sn-write-through="off"` to keep it

A `then` handler writes to the store what write-through writes by itself after the response: an object of a resource's schema is patched into the item with its key (and into what the URL named), a POST to a list's URL inserts the created item, a DELETE of a row's URL removes the row. The handler's write lands on top and changes nothing.

**Fix:** Remove the write from the handler (keep its other statements). To keep the explicit write, turn write-through off for that element with `data-sn-write-through="off"`.

## SN511 image-too-small

Warning, for example:

> `hero.jpg` is 600 px wide; the 400 px box needs 800 px to be sharp on 2x screens

An `<img>` with `width`/`height` smaller than its source is a box of that size, and gets files for 1x and 2x screens (phones, tablets and most laptops are 2x or more). The source has fewer pixels than the 2x file needs, so it is used as the largest file and looks soft on those screens. With a crop (`object-fit: cover`), the width counts after cropping.

**Fix:** Use a larger source, at least the width the message names. A smaller box works too.

## SN512 image-stretched

Warning, for example:

> `width="200" height="200"` has another ratio than `photo.jpg` (1600 × 1067), so the image is stretched

The `width` and `height` of an `<img>` have another ratio than its file, and it has no inline `object-fit`, so the browser stretches the image to fill the box.

**Fix:** To crop to the box, add `style="object-fit: cover"` (and `object-position` for the part to keep): the build makes the cropped file and removes the style. To show the whole image, fix `width`/`height` to the file's ratio, or set only one of them.

## SN513 bound-local-image

Warning, for example:

> `src` is bound to local images (`./logo-dark.png`, `./logo.png`), which are not optimized

An `<img>` binds `src` to a local image path, or chooses between a few of them, with something that can change at runtime. The build optimizes static `<img src>` (formats, widths, dimensions) but cannot follow a path computed at runtime, so the bound image is served as the original file. A `src` over build-time constants (state nothing writes, a prop given as a literal) is written into the page first and optimized, with no warning.

**Fix:** Write each image as a static `<img>` and choose with `data-sn-if` or `data-sn-show`: `<img src="./logo-dark.png" alt="" data-sn-show="dark"><img src="./logo.png" alt="" data-sn-show="!dark">`. Images from the API are a different case: see `images.remote`.

## SN514 auto-fit-rows

Warning, for example:

> this image is in a `repeat(auto-fit, …)` grid whose items are the rows of a `data-sn-for`: its columns stretch when there are fewer items than fit in a row, and how many rows there are is known only at runtime, so its size is not; it gets an upper bound instead

With `auto-fit`, a grid's empty columns collapse: a list shorter than a row stretches its items. The rows of a `data-sn-for` exist only at runtime, so the build cannot tell how wide each item is, and the image gets `sizes` from an upper bound (its container), which may fetch larger files than needed. With `auto-fill` the columns stay the same whatever the number of items, and the build writes exact `sizes`.

**Fix:** Use `repeat(auto-fill, minmax(…, 1fr))` unless short lists should stretch. Otherwise write `sizes` on the image, which silences this.

## SN515 redundant-path

Warning, for example:

> `data-sn-path="/contact/"` is the URL this page has anyway, as a directory's index

A page without `data-sn-path` is written as a directory's index (`contact.html` as `contact/index.html`, served at `/contact/`), so a `data-sn-path` that names only that URL says nothing. The page is built as if it had none.

**Fix:** Remove `data-sn-path`. It lists the paths a page answers at instead: patterns such as `/article/:slug`, or a fixed path such as `/login`, each served by a rewrite to the page's file.

## SN516 unfed-live

Warning, for example:

> `$meta.contacts.live` is always `null`: no `<sn-event resource="contacts">` on this page feeds `contacts`

`$meta.<resource>.live` is the state of the server-event stream that feeds the resource. A resource is fed when an `<sn-event>` in a `<sn-sync>` names it in `resource`; without one, `live` is `null` and a badge built on it never shows a state.

**Fix:** Add an `<sn-event resource="…">` for the resource to the `<sn-sync>`, or read `live` of a resource that a stream feeds.

## SN517 missing-resource-key

Warning, for example:

> `GET /api/contacts` returns a list at `contacts`: resource `contacts` has no `key`, so it is one object holding the list

Without `key` a resource is a single object. A list of objects loads and renders that way, but nothing can change one item: an `upsert` replaces the whole list, `merge` merges fields into the list and `remove` empties it (`[]`). Reported when the OpenAPI response at `select` is a list of objects.

**Fix:** Add `key` with the field that identifies an item, such as `key="id"`. A list that is only read can stay as it is.

## SN518 redundant-shape

Warning, for example:

> `select` of `GET /articles` is configured as `articles` (`main.defaults`): remove it here

The API's `defaults` or `operations` already give this value for the endpoint, so the attribute says nothing. A different value is the error `SN330`.

**Fix:** Remove the attribute.

## SN519 dropped-query

Warning, for example:

> `?page=3` keeps only its own query: `tag`, which this page reads, is dropped when it is followed

A pager link whose `href` is only a query (`?page=3`, or a `data-sn-href` template such as `?page={n}`, setting the parameter a list's `model` (paginate) names) replaces the whole query of the current URL, as any URL resolves: on `/?tag=go` it goes to `/?page=3`, without the tag. The page reads the parameters named, so following the link loses them (in the page, with same-page links, or with a page load). A filter or tab link that drops the page is not reported: that is how a list starts at page 1. Nor is a static `href` kept as the fallback of a bound one.

**Fix:** Keep the parameters in the link's template, `data-sn-href="?tag={$url.tag}&page={n}"` (a parameter that is not set is left out), or leave the parameter out on purpose, for a link that resets it.

## SN520 unused-preload

Warning, for example:

> `index.html` preloads `chart.js` (data-sn-preload), but no module of the app imports it: there is nothing to preload

A `data-sn-preload` names a module that no module of the app imports, so the build has no chunk to preload and the attribute does nothing. Reported by the build.

**Fix:** Remove the name from `data-sn-preload`, or correct it to the module the page's scripts import.

## SN521 redirected-link

Warning, for example:

> `list.html` builds a link to `item.html` at run time, which is served at `/item/` now: it arrives through a redirect

An expression or a link's URL template builds a URL to another page by its file name (`data-sn-href="/item.html?id={i.id}"`, `'/item.html?id=' + i.id`). The build rewrites such links in the markup, but not ones built at run time, so the link costs a redirect to the page's URL. Reported by the build.

**Fix:** Write the page's URL, as the message shows: `data-sn-href="/item/?id={i.id}"`.

## SN522 untranslated-messages

Warning, for example:

> 3 message(s) not translated to `de` (the en text is used): save, cancel, title

The inlang project has messages without a text in one of its languages, so pages in that language show the base language's text. Reported by the build.

**Fix:** Add the translations to the language's message file.

## SN523 first-paint-budget

Warning, for example:

> early script of index.html: assets/index-head.js 12.4 kB gzip, over the first-paint budget of 10.0 kB

The script that renders before the first paint is larger than the budget (`sinter({ firstPaint: { budget } })`, 10 kB gzip by default). It blocks the first frame, so its size is paid on every visit. The message names the largest modules. Reported by the build.

**Fix:** Keep heavy imports out of `src/sinter.early.ts` and of the helpers that early bindings call, or raise the budget.

## SN524 redirects-limit

Warning, for example:

> _redirects has 2400 fixed rules and 12 with patterns; Cloudflare Pages reads at most 2,000 and 100 (Netlify has no such limit)

The `_redirects` file the build writes has more rules than Cloudflare Pages reads; the rest would be ignored there. Reported by the build.

**Fix:** Move the rules beyond the limit to the host's bulk redirects, or turn the file off with `sinter({ redirects: false })`.

## SN525 images-unoptimized

Warning, for example:

> images are not optimized, since sharp is not installed (npm install -D sharp), or sinter({ images: false }) to silence this

Image optimization needs the `sharp` package, which is not installed, so images are served as they are. This depends on the machine, so `--strict` leaves it a warning. Reported by the build, without a file and line.

**Fix:** Install it, `npm install -D sharp`, or turn optimization off with `sinter({ images: false })`.

## SN526 font-download

Warning, for example:

> could not download https://fonts.example/inter.woff2; the page keeps the link (sinter({ fonts: { bundle: false } }) turns this off)

The build bundles the Google Fonts stylesheets a page links to, and one could not be downloaded, so the page keeps the link to the font's host. This depends on the network, so `--strict` leaves it a warning. Reported by the build, without a file and line.

**Fix:** Build with network access, or keep the links with `sinter({ fonts: { bundle: false } })`.

## SN527 css-image-sizes

Warning, for example:

> image sizes from src/styles.scss are not read: Undefined variable $gap

The build reads the page's CSS to size its images, and a stylesheet could not be compiled (by Vite's CSS pipeline, Sass, PostCSS, …). Those images get sizes without that stylesheet. (An `@import 'virtual:…'` of a plugin's CSS is left out first: it does not fail the stylesheet.) This depends on the tools installed, so `--strict` leaves it a warning. Reported by the build, without a file and line.

**Fix:** Fix the error the message shows, or install the preprocessor the stylesheet needs.

## SN528 remote-image

Warning, for example:

> images from the API: fetch failed

In dev, `images.remote` optimizes images from the API, and one could not be fetched or converted. The request answers 502. This depends on the API being reachable, so `--strict` leaves it a warning. Reported by the build, without a file and line.

**Fix:** Check that the API is running and serves the image at that URL.

## SN529 content-sized-list

Warning, for example:

> this list's rows arrive after the first paint inside `<div.col-md-9>`, whose width follows its content: the rows widen it and move what is beside it

The rows of a `data-sn-for` over a resource come after the first paint (without embedded data). The list is inside a box whose width the stylesheets leave to its content: a flex item in a row with no `flex-basis` or `width`, or a float. Empty, that box is narrow and what is beside it sits next to it; once the rows arrive it widens, and its neighbours move or wrap to the next line, a layout shift as large as the boxes that move. The build cannot reserve that width, since it depends on the data. A build keeps what follows the box invisible while the list's first rows load, so nothing shown moves ([first paint](first-paint.md#a-box-whose-width-follows-the-list)); this is reported when it cannot: `data-sn-wait="off"` on the box, or a list whose first load the page cannot tell (a `src` over state, a filter, `for` or `call`). Reported where the stylesheets decide it, at any screen width.

**Fix:** Give the box a width that does not depend on its content: `flex: 1 1 0` or a `flex-basis` in a row, `width: 100%` (or a basis of 100%) where it should take the whole line, as most grid systems do below their breakpoint. With rows of a width of their own (`width` in px or rem) on a paginated list, the build holds the box's width from the first frame, and this is not reported.

## SN530 unsized-late-image

Warning, for example:

> `<img>` in a list whose rows arrive after the first paint has no height before its file loads: when it does, its row grows and what follows moves

An image (or a video, an iframe, an embed) in the rows of a `data-sn-for` over data that comes after the first paint has neither `width` and `height` attributes nor a height or `aspect-ratio` from the stylesheets. Until its file has loaded it is 0 px tall (or its alt text), then it takes its own size, and the row, and everything after the list, moves. With images from an API this happens on every page view. Reported when the build reads the page's stylesheets.

**Fix:** The warning names the fix for that image. When the API gives the image's size next to its URL (its OpenAPI schema has `width` and `height`, `w` and `h`, or `avatarWidth` and `avatarHeight` beside `avatar`), bind them with the URL: `<img data-sn-attr="{src: a.photo.url, width: a.photo.width, height: a.photo.height}">`, with `height: auto` in CSS to keep it fluid. The browser takes the ratio from the attributes before the file loads; nothing runs for it. Otherwise give it `width` and `height` attributes with its ratio, or an `aspect-ratio` in the stylesheets (the warning writes the rule with a selector for it, such as `.person img { width: 100%; aspect-ratio: 4 / 3; object-fit: cover; }`; `object-fit: cover` crops any image to the box), or a fixed height. An image with one of the two attributes is told which one it lacks.

## SN531 encoded-body

Warning, for example:

> `data-sn-body` is already JSON text (`JSON.stringify(…)`): sinter encodes the body, so the server would get a JSON string, not the object

A `data-sn-body` (or a POST `<sn-resource>`'s `body`) calls `JSON.stringify`. sinter encodes the body as JSON itself, so the request carries the JSON text of a string (`"{\"username\":\"alice\"}"`), which a server's JSON parser reads as one string: the fields it expects are missing. A benchmark agent's login with a wrong password went through this way, against an API that compared the missing fields.

**Fix:** Pass the object: `data-sn-body="{ username, password }"`. For another format, set `data-sn-encoding="form"` or send it from an action (`data-sn-call`). The same holds in an actions module or a component script, where the build cannot see it: `ctx.request(url, { body: { username, password } })`, not `body: JSON.stringify(…)`.

## SN532 repeated-id

Warning, for example:

> `id="total"` is in markup that renders more than once (a `data-sn-for` row): the page would have that id more than once

A literal `id` in markup that renders more than once, in a page or a component: a `data-sn-for` row, or a fill of a slot placed more than once. Ids are unique in a page; `getElementById`, `<label for>`, `aria-*` references and `run('id')` find only the first.

**Fix:** Compute the id from the row: `data-sn-attr="{ id: 'total-' + row.id }"`, or move the element out of the repeated markup.

## SN533 helpers-unloaded

Warning, for example:

> the helpers module could not be loaded in Node (src/sinter.helpers.ts: Cannot find module './missing.js'): no helper call is run at build time

The build, the dev server, `sinter check` and the language server load the helpers module in Node, with the app's Vite config, to run helper calls over build-time constants. A module that throws when it loads there (it reads `window` or `document` at its top level, imports a file that is missing, or a package that only runs in a browser) folds nothing: every helper call stays in the browser, as before. Reported once per build or session. Reported by the build, without a file and line.

**Fix:** Move what needs the browser out of the module's top level (into the functions that need it), or into a component script. The page works either way; only build-time folding is lost. Strict mode does not fail on this warning: it depends on what the app imports, not on a mistake.

## SN534 helper-not-folded

Warning, for example:

> `fmt.title()` threw at build time (Cannot read properties of undefined), so this call stays in the browser

A helper call over build-time constants (in a binding or a state initializer) runs in the compiler when the helper may fold, and its result is written into the page. This call did not: the helper threw, returned something that is not plain data (JSON values: a `Date`, a `Map`, a class instance, a function), or, as every build runs each such call twice, returned another result the second time. The call runs in the browser instead, as before; a warning in dev builds, once per call. A production build also runs every page's calls again at its end, in a fresh copy of the helpers module and in reverse page order, and fails with SN534 when a result differs: the helper keeps state between calls (a table of ids, a counter), so each page would show what the build's page order made of it. That check runs in a thread of its own beside the build, which waits for it once Vite has processed the pages: a build it fails has already emptied the output folder (`dist/`) and writes nothing. Reported by the build, without a file and line.

**Fix:** Make the helper return plain data for constant arguments and keep it pure (same arguments, same result, nothing read or changed elsewhere, no state kept between calls; a cache that only remembers is fine). A helper that cannot is fine in the browser: call it from a handler, or over values the browser has.

## SN535 close-slot-name

Warning, for example:

> `<slot name="cel">` in `<x-cell>` is a tree placement, filled by the nearest root that declares `cel`; `<x-cell>` declares a slot of a close name. Did you mean `cell`?

A `<slot>` that passes data, in a component that does not declare its name, is a tree placement: the nearest enclosing component that declares the name fills it (docs/components.md, Tree slots). Its component declares a slot whose name is close, so it is likely a misspelled placement of the component's own slot.

**Fix:** Fix the name to the declared one, or rename the declared slot if the tree placement is meant.

## SN536 expansion-limit

Warning, for example:

> this list's rows would take the page past 10,000 rows and components expanded at build time, so it is rendered in the browser

A constant tree (a loop over constants, a component instantiated over constant props, at any depth) is written into the page as plain HTML at build time. The rows and components a page expands in all are limited, as the layout and image steps then run over the whole page and slow the build. The tree that would cross it stays a template the browser renders, as without build-time expansion; it works the same, with JavaScript.

**Fix:** Split the content over several pages, or keep the long part a list the browser renders. The warning stays a warning with `--strict`.

## SN537 library-version

Warning, for example:

> `@acme/ui` supports sinter `^0.17.0`, and this is sinter 0.18.0: its markup may use what this version does not have, or what it no longer has

A component library ships source that the app's sinter compiles, so it lists the sinter versions it supports in its package.json's `peerDependencies` (`"@tiaforge-ui/sinter": "^0.18.0"`). The app's sinter checks that its own version is in the range, and warns when a library lists none. It cannot know which version introduced a feature newer than itself.

**Fix:** Install a version of sinter or of the library that fits the other. A library's author lists the range in `peerDependencies`.

## SN538 unreachable-candidate

Warning, for example:

> `x-para` can never be chosen here: `b.type` cannot be `"paragraph"` where this `<sn-component>` is (a branch around it rules it out)

`sinter check` checks each candidate of a `<sn-component use>` (a template string or a map) with the data narrowed to its key, and the branches around it (`data-sn-if`, `data-sn-else`) narrow the data too. When they leave no value for a candidate's key, TypeScript finds the comparison can never hold: that component is never rendered there. A warning, since the page still works.

**Fix:** Remove the candidate from `use`, or move the `<sn-component>` out of the branch that excludes it.

## SN539 empty-glob

Warning, for example:

> `file:/content/posts/*.md` matches no file (`content/posts` has none that match): the list is empty

A `file:` glob found no file. The page builds with an empty list, which is usually a typo in a folder or extension rather than an empty blog.

**Fix:** Check the folder and the pattern (`*` stays within a folder, `**` crosses folders). A list that is empty on purpose can stay: this is a warning.

## SN540 swap-script

Warning, for example:

> an inline script in the body does not run when a link swaps this page in (`sinter({ swap: true })`), only on a page load

With swaps on, a link to another page of the app fetches it and swaps its body in: the new page's module runs, its inline and classic scripts do not (and `load` and `DOMContentLoaded` do not fire again). A script in the body that expects a load, analytics, a chat widget, ads, misses each page reached by a link.

**Fix:** Move what it does into the page's code (a component script, the actions module), load it once as `<script type="module" src>` in the head, or take the page out with `<html data-sn-swap="off">` (links to it load it). A script that must run once per app can stay: this is a warning.

## SN541 kept-playback

Warning, for example:

> `muted` of a `<audio>` in a kept element is bound: the next page's code sets it again when a link swaps it in, which interrupts playback

A kept element (`data-sn-permanent`) moves into the next page as it is, and the next page's code takes over its bindings: each binding is written once when it mounts. For `currentTime`, `paused`, `volume`, `muted` or `playbackRate` of a playing `<audio>` or `<video>`, that write is a jump, a pause or a change of volume in the middle of playback.

**Fix:** Leave playback to the element: its controls, or a handler that calls `play()` and `pause()`. Bind `src`, which the next page writes only when it changes (another track starts, as it should).

## SN542 unkeyed-list-write

Warning, for example:

> `upsert(comments, …)` replaces the whole list: resource `comments` has no `key`, and its `type` is `Comment[]`

Without `key` a resource is one object, here one holding a list. A change aimed at one item changes the whole value: `upsert` replaces the list with the item, `merge` merges fields into the list and `remove` sets it to `null`. Reported where `upsert`, `merge` or `remove` (in a handler, or an `<sn-event op>` in a `<sn-sync>`) targets a resource without `key` whose `type` is a list (`Comment[]`, `Array<Comment>`) or whose OpenAPI response is a list (that declaration is also `SN517`). Dev builds also warn at runtime when an `upsert` or `merge` reaches a resource without `key` that holds a list, typed or not.

**Fix:** Add `key` with the field that identifies an item, such as `key="id"`: the resource becomes a list of items, and each change applies to one. To replace the whole list on purpose, reload it with `refresh(name)` or `op="refresh"`.

## SN543 filled-at-mount

Warning, for example:

> `<doc-view>` is filled by its script at mount, after the first paint, where the early script renders what is around it: its content moves what follows it

A component whose root has no content of its own is shown by its script, which runs in the page module, after the first paint. Where the early script renders the page around the use (its props are known before the page module: constants, the URL, [embedded data](first-paint.md#embedded-data)), the page is painted with the root empty, and the script's content then pushes down what follows it (layout shift, CLS). Reported for a use whose props the early script knows, in a page root or in a branch or row it renders, of a component with a script and no early renderer, by the build (`sinter check` does not compile the early script). Not for a component whose root is `hidden`: it shows nothing, whatever its script does. Nor for one whose script writes no content: no DOM-writing call (`innerHTML`, `textContent`, `append`, `replaceChildren`, `createElement`, `cloneNode`, …) and its root passed to no function, such as a resize handle that only listens.

**Fix:** Give the component an early renderer, `<name>.early.ts` beside its script, whose default export fills the root from the props (`export default (root, props) => { … }`): the early script runs it on the pages that use it this way, and the instance sees `this.early` and keeps what it rendered ([docs/components.md](components.md#early-renderers)). Or reserve the root's space with CSS. A component whose content may appear late can stay: this is a warning.

## SN544 click-without-keyboard

Warning, for example:

> `<li>` has a `data-sn-on-click` handler, but takes no focus: a keyboard or screen reader user cannot reach it

A click handler, or an action a click starts (`data-sn-delete`, `data-sn-call` without another `data-sn-trigger`), is on an element that takes no focus: a `<div>`, `<li>`, `<tr>`, `<span>`, a link without an `href`. A mouse can use it; Tab never reaches it, so a keyboard or screen reader user cannot. Not reported when the element has a `role` or `tabindex`, or holds a control (a button, a link, a field) a click inside comes from: the handler then serves those, and the controls are reachable. A warning: the page works with a mouse.

**Fix:** Put the handler or the action on a `<button>` (or a link, `<a data-sn-href>`, if it goes to a page). A whole row that selects: a button in the row. Where the element must stay, add `role="button"`, `tabindex="0"` and `data-sn-on-keydown-enter` with the same handler.

## SN545 late-live-region

Warning, for example:

> this live region (`role="status"`) is the top of a `data-sn-if` template: it appears with its text, and screen readers announce only what changes in a region already on the page

A live region (`aria-live="polite"` or `"assertive"`, `role="status"`, `"log"`, `"timer"` or `"marquee"`) is announced when its content changes. One that is the top element of a `data-sn-if`, `data-sn-else` or `data-sn-for` template is added to the page together with its text, so most screen readers say nothing: "Saved" shows, and no one hears it. `role="alert"` is announced as it appears, and is not reported.

**Fix:** Keep the region on the page and render what changes inside it: `<div role="status"><template data-sn-if="saved">Saved</template></div>`, or `<p role="status" data-sn-text="saved ? 'Saved' : ''"></p>`. For an error, `role="alert"` on the branch is fine.

## SN546 image-alt

Warning, for example:

> `<img>` has no `alt`: a screen reader reads its file name instead

An image without `alt` (written, or bound with `data-sn-attr`), `aria-label`, `aria-labelledby`, `role="presentation"`/`"none"` or `aria-hidden="true"`. A screen reader announces it by its file name or URL, or as an unlabeled image. A warning.

**Fix:** Say what the image shows: `alt="Ada Lovelace"`, or from data, `data-sn-attr="{ alt: user.name }"`. An image that only decorates (an icon next to its label, a background picture) takes `alt=""`, and screen readers skip it.

## SN547 close-component-name

Warning, for example:

> `<text-inptu>` is not a component, so it stays a plain custom element; `<text-input>` is a component. Did you mean `text-input`?

A tag with a `-` that names no component, layout or `sn-*` element is left to the browser as a custom element. When its name is close to a component's (the app's, or a library's public one), it is likely a misspelled use of that component, which would otherwise render nothing and say nothing. A tag close to no component is a web component (`<sl-button>`, `<model-viewer>`) and is not reported, nor is one whose first part differs from the component's by more than one letter (`<sl-button>` beside a component `<ui-button>`). A warning; an error when the tag has `data-sn-with` and its first part is the component's, as the props meant for the component would be set as properties of a plain custom element instead.

**Fix:** Fix the tag to the component's name (the editor's quick fix renames the start and end tags). A genuine custom element of a close name (a web component, or one the app defines with `customElements.define`) works as it is, and the warning does not fail a build; in strict mode, keep it a warning with `strict: { allow: { SN547: '…' } }` (docs/strict.md). There is no switch for one element: if it has `data-sn-with` and is an error, rename the element or the component so their names are not this close.
